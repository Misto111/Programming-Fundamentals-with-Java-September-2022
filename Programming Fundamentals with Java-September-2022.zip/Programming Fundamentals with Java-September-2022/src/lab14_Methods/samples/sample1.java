package lab14_Methods.samples;

import java.util.Scanner;

public class sample1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        printHello();
        printHello();
    }

        public static void printHello() {
            System.out.println("Hello!");
        }
    }


