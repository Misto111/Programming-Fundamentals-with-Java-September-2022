package lab14_Methods.samples;

import java.util.Scanner;

public class sample2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        printText(scanner.nextLine());

    }
    public static void printText(String text) {
        System.out.println(text);
    }
}
