package lab34_ExamPreparation;

import java.util.Scanner;

public class p02AdAstra {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}
