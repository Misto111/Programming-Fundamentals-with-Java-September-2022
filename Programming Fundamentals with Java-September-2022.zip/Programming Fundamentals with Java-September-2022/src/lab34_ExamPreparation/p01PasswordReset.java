package lab34_ExamPreparation;

import java.util.Scanner;

public class p01PasswordReset {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String password = scanner.nextLine();
        String command = scanner.nextLine();
        
        while (!command.equals("Done"))  {
            
            if (command.contains("TakeOdd")){

                
            }else if (command.contains("Cut")){
                
                
            }else if (command.contains("Substitute")){
                
                
            }
            
            
            command = scanner.nextLine();
        }

        
    }


    }

