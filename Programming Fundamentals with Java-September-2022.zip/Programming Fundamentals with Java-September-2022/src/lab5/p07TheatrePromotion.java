package lab5;

import java.util.Scanner;

public class p07TheatrePromotion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String typeDay = scanner.nextLine();
        int age = Integer.parseInt(scanner.nextLine());

        if (0 <= age && 0<= 18){



        }else if (18 < age && age<= 64){

    }else if (64 < age && age<= 122) {


        }

        }
}
