import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Task3 {
    static ArrayList<String> phone;
    public static void main(String[] args) {

        Scanner cs = new Scanner(System.in);
        String s = cs.nextLine();
        phone = (ArrayList) Arrays.stream(s.split(", ")).collect(Collectors.toList());
        Queue<Command> com = new LinkedList<>();
        while (true){
            String command = cs.nextLine();
            if("end".equalsIgnoreCase(command)){
                break;
            }
            List <String> list = Arrays.stream(command.split(" - ")).collect(Collectors.toList());
            Command c = new Command(list.get(0), list.get(1));
            com.offer(c);
        }

        while (!com.isEmpty()){
            Command c = com.poll();
            if(c.key.equalsIgnoreCase("Bonus phone")){
                List<String> values = Arrays.stream(c.value.split(":")).collect(Collectors.toList());
                bonus(values);
            }
            getNextByMethod(c.key, c.value);
        }


        phone.forEach(c -> {
            System.out.print(c + ", ");
        });

    }

    private static void bonus(List<String> values) {
        if(values.size()> 1){
            if(phone.contains(values.get(0))) {
                int index =phone.indexOf(values.get(0));
                phone.add(++index, values.get(1));
            }
        }
    }

    private static void getNextByMethod(String command, String value) {
        switch (command.toLowerCase()){
            case "add" : add(value);
                break;
            case "remove"  : remove(value);
                break;
            case "last"  : last(value);
                break;
        }
    }

    private static void last(String curren) {
        if(curren != null ){
            if(phone.remove(curren)){
                phone.add(curren);
            }
        }
    }

    private static void remove(String ph) {
        if(ph != null) {
            phone.remove(ph);
        }
    }

    private static void add(String addPhone) {
        if(addPhone != null){
            if(!phone.contains(addPhone)){
                phone.add(addPhone);
            }
        }
    }

    public static class Command{
        String key;
        String value;

        public Command(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }
}
