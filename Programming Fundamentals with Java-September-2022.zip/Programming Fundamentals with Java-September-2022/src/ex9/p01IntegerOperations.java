package ex9;

import java.util.Scanner;

public class p01IntegerOperations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int firstNumber = Integer.parseInt(scanner.nextLine());
        int secondNumber = Integer.parseInt(scanner.nextLine());
        int thirdNumber = Integer.parseInt(scanner.nextLine());
        int fourthNumber = Integer.parseInt(scanner.nextLine());

        int sumFirstWithSecond = firstNumber + secondNumber;
        int divideThirdNumber = sumFirstWithSecond / thirdNumber;
        int multiplyForthNumber = divideThirdNumber * fourthNumber;
        System.out.println(multiplyForthNumber);
    }
}
