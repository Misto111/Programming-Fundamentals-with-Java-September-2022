package ex9;

import java.util.Scanner;

public class p02SecondTry {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = Integer.parseInt(scanner.nextLine());

       int  sum = 0;

        for (int i = number; i > 0 ; i--) {
            int lastNumber = number % 10;
            sum += lastNumber;
            number = number /10;

        }
        System.out.println(sum);

    }
}
