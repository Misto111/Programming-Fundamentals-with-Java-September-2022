package ex15_Methods;

import java.util.Scanner;

public class p04PasswordValidator {
    public static void main(String[] args) {
        Scanner scanner =  new Scanner(System.in);

        String password =scanner.nextLine();
    }
}
