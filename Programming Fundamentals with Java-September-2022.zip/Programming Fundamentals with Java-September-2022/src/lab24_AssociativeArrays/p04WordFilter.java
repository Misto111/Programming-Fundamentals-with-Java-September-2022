package lab24_AssociativeArrays;

import java.util.Scanner;

public class p04WordFilter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}
