package RegularFinalExam;

import java.util.Scanner;

public class p01_aa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String commands = scanner.nextLine();

        while (!commands.equals("Abracadabra")) {
            String [] commandsArr = commands.split(" ");

            if (commandsArr.equals("Abjuration")) {






            }




            commands = scanner.nextLine();
        }

    }
}
