package RegularFinalExam;

import java.util.Scanner;

public class p03_cc {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


    }
}
